package cdi.interfacedesign.lolrankedtracker.fragments.screens

import androidx.fragment.app.Fragment

class ConfigurationScreen : Fragment() {
}