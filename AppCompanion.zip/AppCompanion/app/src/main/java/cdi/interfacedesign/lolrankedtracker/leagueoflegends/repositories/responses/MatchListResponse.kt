package cdi.interfacedesign.lolrankedtracker.leagueoflegends.repositories.responses

data class MatchListResponse(var matchList: List<String>? = null)
